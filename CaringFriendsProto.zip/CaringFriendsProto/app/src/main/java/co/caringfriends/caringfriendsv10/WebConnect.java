package co.caringfriends.caringfriendsv10;

/**
 * Created by Mark on 4/2/2017.
 */

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface WebConnect{
    @POST("e/1FAIpQLSecE7uwOOB3fl7Jo8fKxcrpH9EQXlrAIFghEE0frDlsqsy2dg/formResponse")
    @FormUrlEncoded
    Call<Void> completeQuestionnaire(

            @Field("entry.1007246333") String Entry
    );
}