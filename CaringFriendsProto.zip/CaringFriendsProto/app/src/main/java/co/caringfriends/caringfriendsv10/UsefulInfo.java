package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class UsefulInfo extends AppCompatActivity {

    //UNPACK INFO FROM PERSONAL INFO ACTIVITY

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useful_info);

        //Moved this to the class ahead.  We need a splash page with loading.  Look at udemy firebase
        //for this.
        //Want to create our array list of questions first and foremost
        final ArrayList<question> questions = new ArrayList<>();

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        //returns the reference to our entire database
        //we must then add child references to this
        final DatabaseReference databaseReference = database.getReference();

        //this is our child reference of our database.  We can call methods on this
        //and set listeners without crashing our app
        final DatabaseReference optionsArrayRef = databaseReference.child("user0").child("questions");
        optionsArrayRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                //Getting our arraylist of our questions.  We need to loop over this to extract our data and construct our objects
                //Keep in mind you need to cast objects with elements and cant use generics.
                //These have been found to be arraylists of hashmaps.  So matrices.
                ArrayList<Object> listOfQuestions = (ArrayList<Object>)dataSnapshot.getValue();

                for(int i = 0; i<listOfQuestions.size(); i++) {
                    //Each of these is a hashmap, again we cannot have a generic call, we use object for our value
                    //because it could be anything, but our keys are always strings
                    HashMap<String, Object> question = (HashMap<String, Object>)listOfQuestions.get(i);
                    Log.v("Question:", question.toString());

                    //I know it's going to be a string behind every format key, so we can cast it to String.  We can also
                    //grab our question text since every question has one and we know it's a string.
                    String questionFormat = (String)question.get("format");
                    String questionText = (String)question.get("text");

                    //now we need to split the code depending on whether its an open-ended or multiple-choice question
                    if(questionFormat.equals("openEnded")) {
                        questions.add(new openQuestion(questionText));
                    }
                    //The question must be multiple choice then
                    else {
                        //set up an arraylist of type String
                        ArrayList<String> options = (ArrayList<String>) question.get("options");
                        switch(options.size()){
                            case 2:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1)));
                                break;
                            case 3:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1), options.get(2)));
                                break;
                            case 4:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1), options.get(2), options.get(3)));
                                break;
                            default:
                                questions.add(new multiQuestion(questionText, options.get(0), options.get(1)));
                                break;
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        final Button usefulInfoButton = (Button)findViewById(R.id.usefulInfoButton);
        usefulInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //UNPACK
                String nameOfOlderAdult = getIntent().getExtras().getString("NAME_ADULT");
                String nameOfVisitingFriend = getIntent().getExtras().getString("NAME_FRIEND");
                String dateOfVisit = getIntent().getExtras().getString("DATE_VISIT");
                String cityOfVisit = getIntent().getExtras().getString("CITY_VISIT");

                //NO NEW INFORMATION TO CARRY OVER, JUST RETRIEVE THE INTENT FROM CHECK IN AND
                //IMMEDIATELY PASS IT OVER

                Intent intent = new Intent(UsefulInfo.this, Questions.class);

                intent.putExtra("ArrayList", questions);
                intent.putExtra("NAME_ADULT", nameOfOlderAdult);
                intent.putExtra("NAME_FRIEND", nameOfVisitingFriend);
                intent.putExtra("DATE_VISIT", dateOfVisit);
                intent.putExtra("CITY_VISIT", cityOfVisit);

                startActivity(intent);
            }
        });

    }
}
