package co.caringfriends.caringfriendsv10;

import android.app.Activity;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Merged adapter class to fit both question types into one list view.
 * Created by Mark on 6/8/2017.
 */

public class questionAdapter extends ArrayAdapter<question> {

    public questionAdapter(Activity context, ArrayList<question> questions){
        super(context, 0 ,questions);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;

        //Use this layout if the object subclass coming is open-ended
        if(getItem(position).getmObjectType().equals("openEnded")){

            if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.open_ended_list, parent, false);
            }

            openQuestion currentQuestion = (openQuestion)getItem(position);
            TextView openTextView = (TextView)listItemView.findViewById(R.id.openTextView);
            openTextView.setText(currentQuestion.getmQuestionText());

            final EditText openEditText = (EditText)listItemView.findViewById(R.id.openEditText);
            final CheckBox openCheckBox = (CheckBox)listItemView.findViewById(R.id.openCheckbox);

            openEditText.setHint("Enter something...");
            openCheckBox.setText("Skip this question");

            openCheckBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (openCheckBox.isChecked()){
                        openEditText.setText("Question skipped...");
                        openEditText.setEnabled(false);
                        //disable the edittext if they hit the check to skip
                    }
                    else {
                        openEditText.setText("");
                        openEditText.setHint("Enter something...");
                        openEditText.setEnabled(true);
                    }
                }
            });

        }

        //Use this layout if the object sublass coming is multiple choice
        if(getItem(position).getmObjectType().equals("multiChoice")){

            if (listItemView == null) {
                listItemView = LayoutInflater.from(getContext()).inflate(
                        R.layout.multiple_choice_list, parent, false);
            }

            final multiQuestion currentQuestion = (multiQuestion)getItem(position);

            TextView questionTextView = (TextView)listItemView.findViewById(R.id.questionTextView);
            questionTextView.setText(currentQuestion.getmQuestionText());

            final RadioGroup questionRadioGroup = (RadioGroup)listItemView.findViewById(R.id.questionRadioGroup);
            RadioButton questionOption1 = (RadioButton)listItemView.findViewById(R.id.questionOption1);
            RadioButton questionOption2 = (RadioButton)listItemView.findViewById(R.id.questionOption2);
            RadioButton questionOption3 = (RadioButton)listItemView.findViewById(R.id.questionOption3);
            RadioButton questionOption4 = (RadioButton)listItemView.findViewById(R.id.questionOption4);
            RadioButton questionOption5 = (RadioButton)listItemView.findViewById(R.id.questionOption5);

            if(currentQuestion.getmNumberOfOptions() == 3){
                questionOption1.setText(currentQuestion.getmOption1Text());
                questionOption2.setText(currentQuestion.getmOption2Text());
                questionOption3.setText(currentQuestion.getmSkippedText());
                questionOption4.setVisibility(View.GONE);
                questionOption5.setVisibility(View.GONE);
            }
            else if(currentQuestion.getmNumberOfOptions() == 4) {
                questionOption1.setText(currentQuestion.getmOption1Text());
                questionOption2.setText(currentQuestion.getmOption2Text());
                questionOption3.setText(currentQuestion.getmOption3Text());
                questionOption4.setText(currentQuestion.getmSkippedText());
                questionOption5.setVisibility(View.GONE);
            }
            else if(currentQuestion.getmNumberOfOptions() == 5) {
                questionOption1.setText(currentQuestion.getmOption1Text());
                questionOption2.setText(currentQuestion.getmOption2Text());
                questionOption3.setText(currentQuestion.getmOption3Text());
                questionOption4.setText(currentQuestion.getmOption4Text());
                questionOption5.setText(currentQuestion.getmSkippedText());
            }


        questionRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                currentQuestion.setRadioGroup(questionRadioGroup);
                RadioButton checkedButton = (RadioButton)(group.findViewById(checkedId));
                currentQuestion.setResponse(checkedButton.getText().toString());

            }
        });

        }
        return listItemView;
    }
}
