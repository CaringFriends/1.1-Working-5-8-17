package co.caringfriends.caringfriendsv10;

import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

/**
 * Created by Mark on 4/18/2017.
 */

public class multiQuestion extends Questions{
    //extending the class gives us the context we need to use findviewbyid

    private String mQuestionText;
    private RadioGroup mQuestionGroup;
    private String mOption1Text;
    private String mOption2Text;
    private String mOption3Text;
    private String mOption4Text;
    private String mResponse;

    public multiQuestion(String questionText, RadioGroup questionGroup, String option1, String option2, String option3, String option4) {

        mQuestionText = questionText;
        mQuestionGroup = questionGroup;
        mOption1Text = option1;
        mOption2Text = option2;
        mOption3Text = option3;
        mOption4Text = option4;
    }

    public String getCheckedText(int index){

        RadioButton button = (RadioButton)findViewById(mQuestionGroup.getCheckedRadioButtonId());
        return button.getText().toString();
    }

    public void setIndexed(int index){
        if (index == R.id.questionOption1) mResponse = getmOption1Text();
        if (index == R.id.questionOption2) mResponse = getmOption2Text();
        if (index == R.id.questionOption3) mResponse = getmOption3Text();
        if (index == R.id.questionOption4) mResponse = getmOption4Text();
        if (index == R.id.questionOption5) mResponse = getmOption5Text();
    }

    public String getResponse() {
        return mResponse;
    }

    public String getQuestionText() {
        return mQuestionText;
    }

    public String getmOption1Text() {
        return mOption1Text;
    }

    public String getmOption2Text() {
        return mOption2Text;
    }

    public String getmOption3Text() {
        return mOption3Text;
    }

    public String getmOption4Text() {
        return mOption4Text;
    }

    public String getmOption5Text() {
        return "Skip this question...";
    }
}
