package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class Observations extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);

        RadioGroup observation1Group = new RadioGroup(Observations.this);
        RadioGroup observation2Group = new RadioGroup(Observations.this);
        RadioGroup observation3Group = new RadioGroup(Observations.this);
        RadioGroup observation4Group = new RadioGroup(Observations.this);
        RadioGroup observation5Group = new RadioGroup(Observations.this);
        RadioGroup observation6Group = new RadioGroup(Observations.this);
        RadioGroup observation7Group = new RadioGroup(Observations.this);
        RadioGroup observation8Group = new RadioGroup(Observations.this);
        RadioGroup observation9Group = new RadioGroup(Observations.this);
        RadioGroup observation10Group = new RadioGroup(Observations.this);
        RadioGroup observation11Group = new RadioGroup(Observations.this);
        RadioGroup observation12Group = new RadioGroup(Observations.this);
        RadioGroup observation13Group = new RadioGroup(Observations.this);
        RadioGroup observation14Group = new RadioGroup(Observations.this);
        multiQuestion question1 = new multiQuestion(getString(R.string.obs1Q), observation1Group, "Clean", "Reasonable", "Somewhat Messy", "Really Needs Help");
        multiQuestion question2 = new multiQuestion(getString(R.string.obs2Q), observation2Group, "Clean", "Reasonable", "Somewhat Messy", "Really Needs Help");
        multiQuestion question3 = new multiQuestion(getString(R.string.obs3Q), observation3Group, "No Odor", "Slight Odor", "Fairly Odorous", "Very Odorous");
        multiQuestion question4 = new multiQuestion(getString(R.string.obs4Q), observation4Group, "No Odor", "Slight Odor", "Fairly Odorous", "Very Odorous");
        multiQuestion question5 = new multiQuestion(getString(R.string.obs5Q), observation5Group, "Very Coherent", "Slightly Confused", "Fairly Confused", "Incoherent");
        multiQuestion question6 = new multiQuestion(getString(R.string.obs6Q), observation6Group, "High Energy", "Fairly Energetic", "Low Energy", "Lethargic");
        multiQuestion question7 = new multiQuestion(getString(R.string.obs7Q), observation7Group, "Positive", "Neutral", "Negative", "");
        multiQuestion question8 = new multiQuestion(getString(R.string.obs8Q), observation8Group, "Highly Mobile", "Somewhat Mobile", "Not Moving Much", "Immobile");
        multiQuestion question9 = new multiQuestion(getString(R.string.obs9Q), observation9Group, "Yes", "No", "", "");
        multiQuestion question10 = new multiQuestion(getString(R.string.obs10Q), observation10Group, "Yes", "No", "", "");
        multiQuestion question11 = new multiQuestion(getString(R.string.obs11Q), observation11Group, "None", "Mild", "Somewhat", "Significant");
        multiQuestion question12 = new multiQuestion(getString(R.string.obs12Q), observation12Group, "Too Hot", "A Little Hot", "Just Right", "A Little Cold");
        multiQuestion question13 = new multiQuestion(getString(R.string.obs13Q), observation13Group, "Yes", "No", "", "");
        multiQuestion question14 = new multiQuestion(getString(R.string.obs14Q), observation14Group, "Very Well Cared For", "Somewhat Neglected", "Very Neglected", "");




        //ESTABLISH RETROFIT DATA CONNECTION
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://docs.google.com/forms/d/")
                .build();
        final WebConnect spreadsheetWebService = retrofit.create(WebConnect.class);

        //FIND ALL OF THE RADIO GROUPS

        final ArrayList<multiQuestion> multiQuestions = new ArrayList<multiQuestion>();
        multiQuestions.add(question1);
        multiQuestions.add(question2);
        multiQuestions.add(question3);
        multiQuestions.add(question4);
        multiQuestions.add(question5);
        multiQuestions.add(question6);
        multiQuestions.add(question7);
        multiQuestions.add(question8);
        multiQuestions.add(question9);
        multiQuestions.add(question10);
        multiQuestions.add(question11);
        multiQuestions.add(question12);
        multiQuestions.add(question13);
        multiQuestions.add(question14);


        multiAdapter adapter = new multiAdapter(Observations.this, multiQuestions);

        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);

        //Call<Void> completeQuestionnaireCall = spreadsheetWebService.completeQuestionnaire(nameOfOlderAdult);
        //completeQuestionnaireCall.enqueue(callCallback);

        TextView header = new TextView(this);
        header.setText(R.string.headerMultiText);
        listView.addHeaderView(header);

        Button button = new Button(this);
        listView.addFooterView(button);
        button.setText(R.string.buttonText);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fullText = "";

                for (int i = 0; i<multiQuestions.size(); i++){
                    multiQuestion defaultQuestion = multiQuestions.get(i);
                    String questionText = defaultQuestion.getQuestionText();
                    String response = defaultQuestion.getResponse();
                    fullText += questionText + "\n" + response + "\n\n";
                }

                Log.v("Observations", fullText);

                Intent intent = new Intent(Observations.this, Notes.class);
                startActivity(intent);
                //move to the next activity
            }
        });
    }

    private final Callback<Void> callCallback = new Callback<Void>() {
        @Override
        public void onResponse(Response<Void> response) {
            Log.d("XXX", "Submitted. " + response);
        }

        @Override
        public void onFailure(Throwable t) {
            Log.e("XXX", "Failed", t);
        }
    };
}