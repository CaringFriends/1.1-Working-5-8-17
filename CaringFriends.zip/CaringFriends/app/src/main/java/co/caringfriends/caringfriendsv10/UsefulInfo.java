package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UsefulInfo extends AppCompatActivity {

    //UNPACK INFO FROM PERSONAL INFO ACTIVITY

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useful_info);

        final Button usefulInfoButton = (Button)findViewById(R.id.usefulInfoButton);
        usefulInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //UNPACK
                String nameOfOlderAdult = getIntent().getExtras().getString("NAME_ADULT");
                String nameOfVisitingFriend = getIntent().getExtras().getString("NAME_FRIEND");
                String dateOfVisit = getIntent().getExtras().getString("DATE_VISIT");
                String cityOfVisit = getIntent().getExtras().getString("CITY_VISIT");

                //NO NEW INFORMATION TO CARRY OVER, JUST RETRIEVE THE INTENT FROM CHECK IN AND
                //IMMEDIATELY PASS IT OVER

                Intent intent = new Intent(UsefulInfo.this, Questions.class);

                intent.putExtra("NAME_ADULT", nameOfOlderAdult);
                intent.putExtra("NAME_FRIEND", nameOfVisitingFriend);
                intent.putExtra("DATE_VISIT", dateOfVisit);
                intent.putExtra("CITY_VISIT", cityOfVisit);

                startActivity(intent);
            }
        });

    }
}
