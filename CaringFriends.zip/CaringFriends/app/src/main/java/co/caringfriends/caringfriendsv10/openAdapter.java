package co.caringfriends.caringfriendsv10;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Class to be applied to open-ended questions.
 * Created by Mark on 4/18/2017.
 */

public class openAdapter extends ArrayAdapter<openQuestion>{

    public openAdapter(Activity context, ArrayList<openQuestion>openQuestions){
        super(context, 0 ,openQuestions);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.open_ended_list, parent, false);
        }

        openQuestion currentQuestion = getItem(position);
        TextView openTextView = (TextView)listItemView.findViewById(R.id.openTextView);
        openTextView.setText(currentQuestion.getQuestionText());

        final EditText openEditText = (EditText)listItemView.findViewById(R.id.openEditText);
        final CheckBox openCheckBox = (CheckBox)listItemView.findViewById(R.id.openCheckbox);

        openEditText.setHint("Enter something...");
        openCheckBox.setText("Skip this question");

        openCheckBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (openCheckBox.isChecked()){
                    openEditText.setText("Question skipped...");
                    openEditText.setEnabled(false);
                    //disable the edittext if they hit the check to skip
                }
                else {
                    openEditText.setText("");
                    openEditText.setHint("Enter something...");
                    openEditText.setEnabled(true);
                }
            }
        });

        return listItemView;
    }
}
