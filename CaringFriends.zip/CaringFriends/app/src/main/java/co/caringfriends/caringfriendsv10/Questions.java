package co.caringfriends.caringfriendsv10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class Questions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);

        ArrayList<openQuestion> openQuestions = new ArrayList<openQuestion>();
        openQuestions.add(new openQuestion("example open ended"));
        openQuestions.add(new openQuestion("example open ended2"));

        openAdapter adapter = new openAdapter(Questions.this, openQuestions);

        ListView listView = (ListView)findViewById(R.id.list);
        listView.setAdapter(adapter);

        TextView header = new TextView(this);
        header.setText(R.string.headerOpenText);
        listView.addHeaderView(header);

        Button button = new Button(this);
        listView.addFooterView(button);
        button.setText(R.string.buttonText);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(Questions.this, Observations.class);
                startActivity(intent);
                //move to the next activity
            }
        });

        //UNPACK INFO FROM USEFUL INFO ACTIVITY

        String nameOfOlderAdult = getIntent().getExtras().getString("NAME_ADULT");
        String nameOfVisitingFriend = getIntent().getExtras().getString("NAME_FRIEND");
        String dateOfVisit = getIntent().getExtras().getString("DATE_VISIT");
        String cityOfVisit = getIntent().getExtras().getString("CITY_VISIT");
    }

    public boolean checkEmpty(EditText Text) {

        return Text.getText().toString().trim().length() == 0;
    }

    public String concatenate(String question, String response) {
        return (question + "\n" + response);
    }

    public RadioButton findRadio(RadioGroup group) {
        return (RadioButton) findViewById(group.getCheckedRadioButtonId());
    }
}
