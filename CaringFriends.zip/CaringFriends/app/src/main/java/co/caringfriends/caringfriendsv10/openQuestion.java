package co.caringfriends.caringfriendsv10;

import android.widget.EditText;

/**
 * Created by Mark on 4/18/2017.
 */

public class openQuestion {

    private String mQuestionText;

    openQuestion(String questionText) {

        mQuestionText = questionText;
    }

    public String getQuestionText(){
        return mQuestionText;
    }
}
